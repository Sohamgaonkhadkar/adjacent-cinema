import type { TestCardData } from "../types";

export function testCardToText(card: TestCardData, extra?: { bet?: string; runId?: string }) {
  const lines = [
    "ADJACENT CINEMA — TEST CARD",
    "────────────────────────────────",
    `data_status: ${card.dataStatus.toUpperCase()}`,
    extra?.runId ? `run_id: ${extra.runId}` : null,
    `film: ${card.filmTitle || "—"}`,
    extra?.bet ? `programme_bet: ${extra.bet}` : null,
    "",
    "HYPOTHESIS",
    card.hypothesis || "—",
    "",
    "COMPARISON PROTOCOL",
    card.comparisonProtocol || "—",
    "",
    "PRIMARY MEASURE",
    card.primaryMeasure || "—",
    "",
    "DECISION RULE",
    card.decisionRule || "—",
    "",
    "OBSERVATION WINDOW",
    card.observationWindow || "—",
    "",
    "FALSIFICATION",
    card.falsification || "—",
    "",
    "INTERPRETATION LIMIT",
    "Qloo affinity is a cultural-similarity signal. It is not audience size, viewing probability, attendance, conversion, sponsorship likelihood, revenue or return on investment.",
    "A saved Test Card is a planned experiment. Saving does not mean the experiment has been run.",
    "Missing measurements remain missing. Zero is recorded as zero.",
    card.dataStatus === "fixture"
      ? "This export is from a labelled fixture demonstration, not a live Qloo analysis."
      : null,
  ].filter((line) => line !== null);

  return lines.join("\n");
}

export function downloadText(filename: string, content: string) {
  const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
