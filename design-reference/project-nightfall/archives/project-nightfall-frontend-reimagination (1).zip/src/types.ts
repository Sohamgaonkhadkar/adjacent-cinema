export type Route = "home" | "creator" | "cinema" | "sponsor";

export type ClaimKind = "FACT" | "INTERPRETATION" | "HYPOTHESIS" | "UNKNOWN";

export type DataStatus = "fixture" | "live" | "unavailable" | "insufficient" | "failed";

export type RunStatus =
  | "idle"
  | "running"
  | "completed"
  | "insufficient"
  | "failed"
  | "unavailable"
  | "cancelled";

export type EvaluationVerdict = "SUPPORTED" | "CONTRADICTED" | "INCONCLUSIVE";

export type ObservationKind = "OBSERVED" | "PARTIAL" | "MISSING" | "UNAVAILABLE" | "FAILED";

export type StrategyId = "anchor" | "bridge" | "frontier";

export type ReferenceWork = {
  title: string;
  year: string;
};

export type FilmBrief = {
  title: string;
  logline: string;
  genre: string;
  language: string;
  themes: string;
  comparables: ReferenceWork[];
  releaseGoal: string;
  location: string;
};

export type GraphNode = {
  id: string;
  label: string;
  kind: "film" | "cohort" | "entity" | "tag";
  domain?: string;
  affinity?: number | null;
  members?: string[];
  sourceCallId?: string | null;
  claim: ClaimKind;
  note: string;
  related: string[];
  rejected?: boolean;
  rejectReason?: string;
};

export type ProgrammeBet = {
  primary: string;
  runnerUp?: string;
  rationale: string;
  limitations: string[];
  claim: ClaimKind;
};

export type TestCardData = {
  filmTitle: string;
  hypothesis: string;
  comparisonProtocol: string;
  primaryMeasure: string;
  decisionRule: string;
  observationWindow: string;
  falsification: string;
  dataStatus: DataStatus;
};

export type Observation = {
  id: string;
  at: string;
  kind: ObservationKind;
  note: string;
  value?: string;
};

export type Evaluation = {
  id: string;
  at: string;
  verdict: EvaluationVerdict;
  note: string;
  supersedes?: string;
};

export type Experiment = {
  id: string;
  createdAt: string;
  filmTitle: string;
  bet: string;
  testCard: TestCardData;
  dataStatus: DataStatus;
  observations: Observation[];
  evaluations: Evaluation[];
};

export type CinemaProgrammeEntry = {
  title: string;
  year: string;
  note: string;
};

export type CinemaBrief = {
  venue: string;
  city: string;
  programme: CinemaProgrammeEntry[];
};

export type SponsorCampaign = {
  filmTitle: string;
  logline: string;
  goal: string;
  territory: string;
  notes: string;
};

export type SponsorDraft = {
  id: string;
  version: number;
  at: string;
  body: string;
};

export type SourceReview = {
  id: string;
  at: string;
  source: string;
  finding: string;
};

export type OutreachRecord = {
  id: string;
  at: string;
  brand: string;
  channel: string;
  outcome: string;
  note: string;
};
