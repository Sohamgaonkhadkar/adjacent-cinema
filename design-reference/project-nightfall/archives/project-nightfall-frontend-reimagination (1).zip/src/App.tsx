import { useEffect, useState } from "react";
import type { Route } from "./types";
import { Nav } from "./components/Nav";
import { Footer } from "./components/Footer";
import { Home } from "./pages/Home";
import { Creator } from "./pages/Creator";
import { Cinema } from "./pages/Cinema";
import { Sponsor } from "./pages/Sponsor";

function fromPath(pathname: string): Route | null {
  const path = pathname.replace(/\/+$/, "");
  if (path.endsWith("/creator/sponsor")) return "sponsor";
  if (path.endsWith("/creator")) return "creator";
  if (path.endsWith("/cinema")) return "cinema";
  if (path === "" || path === "/") return "home";
  return null;
}

function parseLocation(): { route: Route; query: string } {
  // Real route paths win (Next.js App Router uses /, /creator, /cinema, /creator/sponsor).
  const direct = fromPath(window.location.pathname);
  if (direct && !window.location.hash) {
    return { route: direct, query: window.location.search.replace(/^\?/, "") };
  }
  const hash = window.location.hash.replace(/^#/, "");
  const [pathPart, query = ""] = hash.split("?");
  const path = pathPart.replace(/^\//, "");
  if (path.startsWith("creator/sponsor") || path === "sponsor") {
    return { route: "sponsor", query };
  }
  if (path.startsWith("creator")) return { route: "creator", query };
  if (path.startsWith("cinema")) return { route: "cinema", query };
  return { route: "home", query };
}

function toHash(route: Route, query?: string) {
  const path =
    route === "home" ? "/" : route === "sponsor" ? "/creator/sponsor" : `/${route}`;
  return `#${path}${query ? `?${query}` : ""}`;
}

export default function App() {
  const [{ route, query }, setLoc] = useState(parseLocation);

  useEffect(() => {
    const onHash = () => setLoc(parseLocation());
    window.addEventListener("hashchange", onHash);
    if (!window.location.hash) {
      window.location.hash = "#/";
    }
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const navigate = (next: Route, q?: string) => {
    window.location.hash = toHash(next, q);
    window.scrollTo(0, 0);
  };

  const fixtureIntent = route === "creator" && /demo=fixture/.test(query);

  return (
    <div className="min-h-screen bg-ink text-paper">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[80] focus:bg-paper focus:px-4 focus:py-2 focus:text-ink"
      >
        Skip to content
      </a>
      <Nav route={route} onNavigate={navigate} overlay={route === "home"} />
      <main id="main">
        {route === "home" && <Home onNavigate={navigate} />}
        {route === "creator" && <Creator fixtureIntent={fixtureIntent} />}
        {route === "cinema" && <Cinema />}
        {route === "sponsor" && <Sponsor />}
      </main>
      <Footer onNavigate={navigate} />
    </div>
  );
}
