import type {
  CinemaBrief,
  Experiment,
  FilmBrief,
  GraphNode,
  ProgrammeBet,
  TestCardData,
} from "../types";

export const FIXTURE_LABEL = "FIXTURE DEMONSTRATION — NOT A LIVE QLOO ANALYSIS";

export const saltLightBrief: FilmBrief = {
  title: "Salt Light",
  logline:
    "A teenage projectionist in a fading coastal cinema inherits her father's last reel and must decide whether the town's only screen stays open.",
  genre: "Drama",
  language: "English",
  themes: "inheritance, small-town ritual, analog memory, coastal labour",
  comparables: [
    { title: "Aftersun", year: "2022" },
    { title: "The Florida Project", year: "2017" },
    { title: "Wendy and Lucy", year: "2008" },
  ],
  releaseGoal: "Festival circuit, then a limited independent theatrical run",
  location: "Brighton, United Kingdom",
};

export const saltLightNodes: GraphNode[] = [
  {
    id: "film",
    label: "Salt Light",
    kind: "film",
    claim: "HYPOTHESIS",
    note: "Working title under investigation. Not a Qloo entity until resolved.",
    related: ["c1", "c2", "c3", "c4"],
  },
  {
    id: "c1",
    label: "Analog inheritance dramas",
    kind: "cohort",
    domain: "Film",
    affinity: 0.81,
    members: ["Aftersun", "The Souvenir", "Petite Maman"],
    sourceCallId: "fix-call-014",
    claim: "FACT",
    note: "Ranked cultural cohort returned by the fixture analysis. Affinity is a similarity signal, not an audience-size estimate.",
    related: ["film", "e1", "e2", "e3"],
  },
  {
    id: "c2",
    label: "Coastal working-class coming-of-age",
    kind: "cohort",
    domain: "Film",
    affinity: 0.74,
    members: ["The Florida Project", "Wendy and Lucy", "Fish Tank"],
    sourceCallId: "fix-call-021",
    claim: "FACT",
    note: "Second-ranked cohort. Members listed are fixture-resolved references, not predicted viewers.",
    related: ["film", "e4", "e5"],
  },
  {
    id: "c3",
    label: "Field-recording scores",
    kind: "cohort",
    domain: "Music",
    affinity: 0.61,
    members: ["sparse piano", "room tone", "coastal ambience"],
    sourceCallId: "fix-call-033",
    claim: "INTERPRETATION",
    note: "Cross-domain adjacency suggested from taste-profile expansion. Not a playlist recommendation.",
    related: ["film", "e6"],
  },
  {
    id: "c4",
    label: "Fading seaside towns",
    kind: "cohort",
    domain: "Place",
    affinity: 0.58,
    members: ["English south coast", "off-season resorts"],
    sourceCallId: "fix-call-041",
    claim: "INTERPRETATION",
    note: "Geographic adjacency is illustrative in this fixture. Live geography appears only when a run returns usable place data.",
    related: ["film", "e7"],
  },
  {
    id: "c5",
    label: "Prestige awards circuit",
    kind: "cohort",
    domain: "Industry",
    affinity: null,
    claim: "UNKNOWN",
    note: "Rejected: insufficient supporting entities after identity resolution.",
    related: [],
    rejected: true,
    rejectReason: "Insufficient evidence — too few resolved members after identity checks.",
  },
  {
    id: "e1",
    label: "Aftersun",
    kind: "entity",
    domain: "Film",
    sourceCallId: "fix-call-008",
    claim: "FACT",
    note: "Resolved comparable. Year 2022 matched. Used as a seed, not as a forecast of overlap.",
    related: ["c1", "film"],
  },
  {
    id: "e2",
    label: "The Souvenir",
    kind: "entity",
    domain: "Film",
    sourceCallId: "fix-call-016",
    claim: "FACT",
    note: "Expanded neighbour within analog-inheritance dramas.",
    related: ["c1"],
  },
  {
    id: "e3",
    label: "Petite Maman",
    kind: "entity",
    domain: "Film",
    sourceCallId: "fix-call-016",
    claim: "FACT",
    note: "Expanded neighbour. Memory and inheritance without spectacle.",
    related: ["c1"],
  },
  {
    id: "e4",
    label: "Wendy and Lucy",
    kind: "entity",
    domain: "Film",
    sourceCallId: "fix-call-008",
    claim: "FACT",
    note: "Resolved comparable. Year 2008 matched.",
    related: ["c2", "film"],
  },
  {
    id: "e5",
    label: "The Florida Project",
    kind: "entity",
    domain: "Film",
    sourceCallId: "fix-call-008",
    claim: "FACT",
    note: "Resolved comparable. Year 2017 matched.",
    related: ["c2", "film"],
  },
  {
    id: "e6",
    label: "Room-tone piano",
    kind: "tag",
    domain: "Music",
    sourceCallId: "fix-call-033",
    claim: "INTERPRETATION",
    note: "Tag-level adjacency from the taste profile. Not a composer recommendation.",
    related: ["c3"],
  },
  {
    id: "e7",
    label: "Off-season resorts",
    kind: "tag",
    domain: "Place",
    sourceCallId: "fix-call-041",
    claim: "INTERPRETATION",
    note: "Place tag from fixture geography. Live maps require returned coordinates.",
    related: ["c4"],
  },
];

export const saltLightBet: ProgrammeBet = {
  primary:
    "Position Salt Light inside analog-inheritance dramas rather than as a generic coming-of-age title.",
  runnerUp: "A quieter coastal-labour frame, using seaside-town adjacency as secondary colour.",
  rationale:
    "The strongest supported cohort clusters around films that treat analog media and family memory as the dramatic engine. Coming-of-age is present but weaker as a primary frame — it would blur the film into a much larger, less distinctive field.",
  limitations: [
    "Affinity is cultural similarity, not predicted attendance.",
    "Rejected 'prestige awards circuit' for insufficient members.",
    "Location signal is fixture-illustrative; it is not a booking forecast.",
  ],
  claim: "HYPOTHESIS",
};

export const saltLightTestCard: TestCardData = {
  filmTitle: "Salt Light",
  hypothesis:
    "A positioning that emphasises analog inheritance (projection, last reels, the cinema as heirloom) will show stronger cultural-affinity alignment with the analog-inheritance cohort than a generic coming-of-age frame.",
  comparisonProtocol:
    "Exploratory comparison: two cuts of the same festival one-sheet and trailer slate — A: analog-inheritance language; B: coming-of-age language — shown to the same mailing list in alternating order. Not a randomised platform split unless the publishing tool supports it.",
  primaryMeasure:
    "Qualitative: which frame independent programmers and peers name first when describing the film after viewing the materials. Secondary: click-through on the one-sheet, recorded as observed counts only.",
  decisionRule:
    "Set by the filmmaker before launch. Suggested form: if a clear majority of programmer responses name the analog-inheritance frame without prompting, treat the bet as supported. Do not invent a percentage threshold here.",
  observationWindow: "Four weeks from first festival mailing.",
  falsification:
    "If respondents consistently describe the film as generic coming-of-age, or if the two frames are indistinguishable in response, the bet is contradicted or inconclusive — not silently confirmed.",
  dataStatus: "fixture",
};

export const saltLightExperiment: Experiment = {
  id: "exp-fixture-001",
  createdAt: "2026-03-12T10:00:00.000Z",
  filmTitle: "Salt Light",
  bet: saltLightBet.primary,
  testCard: saltLightTestCard,
  dataStatus: "fixture",
  observations: [
    {
      id: "obs-1",
      at: "2026-04-02T18:20:00.000Z",
      kind: "PARTIAL",
      note: "Eleven programmer replies. Seven named projection/inheritance first. Four used coming-of-age language. Two mailings still outstanding.",
      value: "7 of 11 named inheritance first",
    },
  ],
  evaluations: [
    {
      id: "eval-1",
      at: "2026-04-09T09:00:00.000Z",
      verdict: "INCONCLUSIVE",
      note: "Directionally consistent with the bet, but the sample is small and two replies are missing. Missing is not zero. A later evaluation can supersede this without rewriting it.",
    },
  ],
};

export const cinemaBrief: CinemaBrief = {
  venue: "The Light House",
  city: "Brighton",
  programme: [
    {
      title: "Aftersun",
      year: "2022",
      note: "Memory, fatherhood, analog video.",
    },
    {
      title: "Wendy and Lucy",
      year: "2008",
      note: "Precarity on the road.",
    },
    {
      title: "The Souvenir",
      year: "2019",
      note: "A filmmaker inherits a life.",
    },
  ],
};

export const cinemaBet: ProgrammeBet = {
  primary:
    "Programme the next slot as an analog-memory double bill rather than a 'women in independent cinema' catch-all.",
  runnerUp: "A coastal-precarity night pairing Wendy and Lucy with a local short.",
  rationale:
    "The three titles share a stronger cultural field around analog memory and intimate realism than around a demographic label. A catch-all frame would flatten what the programme already makes visible.",
  limitations: [
    "This is a programming hypothesis, not a box-office prediction.",
    "Geographic evidence is shown only when coordinates exist. This fixture includes city context without fabricating a heat map.",
  ],
  claim: "HYPOTHESIS",
};

export const cinemaTestCard: TestCardData = {
  filmTitle: "The Light House — analog-memory slot",
  hypothesis:
    "Framing the next screening as an analog-memory conversation (intro + post-film discussion) will attract a more coherent audience conversation than a generic 'indie drama' listing.",
  comparisonProtocol:
    "Two consecutive midweek slots at the same venue. Week 1: analog-memory copy. Week 2: generic indie-drama copy. Same start time, same ticket price. Exploratory — not a randomised trial.",
  primaryMeasure:
    "Observed attendance (actual tickets scanned) and a three-question exit note: what they thought the night was 'about'. Zero attendance is recorded as zero, not as missing.",
  decisionRule:
    "Programmer sets the threshold before the first listing. Suggested: if exit notes cluster on memory/inheritance in week 1 and scatter in week 2, treat as supported. Do not use revenue as the primary measure.",
  observationWindow: "Two consecutive weeks.",
  falsification:
    "If both listings produce indistinguishable descriptions, or if attendance cannot be compared (sell-out, weather cancellation), the result is inconclusive.",
  dataStatus: "fixture",
};

export const analysisStages = [
  {
    id: "validate",
    label: "Validate inputs",
    detail: "Title, references and themes are checked. Nothing is assumed from the logline alone.",
  },
  {
    id: "resolve",
    label: "Resolve identities",
    detail: "Comparable works are matched to entities. Unresolved titles stay unresolved.",
  },
  {
    id: "tags",
    label: "Resolve theme tags",
    detail: "Themes are queried as tags, not as extra film titles.",
  },
  {
    id: "profile",
    label: "Build taste profile",
    detail: "A cultural profile is assembled only from resolved signals.",
  },
  {
    id: "expand",
    label: "Expand adjacent worlds",
    detail: "Neighbouring cohorts are requested and bounded.",
  },
  {
    id: "rank",
    label: "Rank and exclude",
    detail: "Cohorts are ranked. Insufficient worlds remain visible as rejections.",
  },
  {
    id: "compose",
    label: "Compose the bet",
    detail: "A Programme Bet and Test Card are drafted for the filmmaker to edit.",
  },
];

export const emptyTestCard = (title = ""): TestCardData => ({
  filmTitle: title,
  hypothesis: "",
  comparisonProtocol: "",
  primaryMeasure: "",
  decisionRule: "",
  observationWindow: "",
  falsification: "",
  dataStatus: "fixture",
});
