import { useState } from "react";
import { Check, Download } from "lucide-react";
import type { OutreachRecord, SourceReview, SponsorCampaign, SponsorDraft } from "../types";
import { photos } from "../data/photos";
import { PhotoFrame } from "../components/PhotoFrame";
import { Field, TextArea, TextInput } from "../components/Field";
import { uid, formatWhen } from "../lib/storage";
import { cn } from "../utils/cn";

const STEPS = [
  "Intake",
  "Discovery",
  "Evidence",
  "Draft",
  "Review",
  "Approval",
  "Export",
  "Outreach",
] as const;

type Step = (typeof STEPS)[number];

export function Sponsor() {
  const [step, setStep] = useState<Step>("Intake");
  const [campaign, setCampaign] = useState<SponsorCampaign>({
    filmTitle: "",
    logline: "",
    goal: "",
    territory: "",
    notes: "",
  });
  const [drafts, setDrafts] = useState<SponsorDraft[]>([]);
  const [draftBody, setDraftBody] = useState("");
  const [reviews, setReviews] = useState<SourceReview[]>([]);
  const [source, setSource] = useState("");
  const [finding, setFinding] = useState("");
  const [approved, setApproved] = useState(false);
  const [outreach, setOutreach] = useState<OutreachRecord[]>([]);
  const [brand, setBrand] = useState("");
  const [channel, setChannel] = useState("Email");
  const [outcome, setOutcome] = useState("Sent");
  const [note, setNote] = useState("");
  const [notice, setNotice] = useState<string | null>(null);
  const [discovering, setDiscovering] = useState(false);
  const [discoveryState, setDiscoveryState] = useState<"idle" | "unavailable">("idle");

  const idx = STEPS.indexOf(step);
  const canApprove = reviews.length > 0 && drafts.length > 0 && !approved;

  const saveDraft = () => {
    if (!draftBody.trim()) return;
    const d: SponsorDraft = {
      id: uid("draft"),
      version: drafts.length + 1,
      at: new Date().toISOString(),
      body: draftBody.trim(),
    };
    setDrafts((prev) => [d, ...prev]);
    setNotice(`Draft v${d.version} saved. Versions accumulate; none are silently overwritten.`);
  };

  const addReview = () => {
    if (!source.trim() || !finding.trim()) return;
    setReviews((prev) => [
      {
        id: uid("rev"),
        at: new Date().toISOString(),
        source: source.trim(),
        finding: finding.trim(),
      },
      ...prev,
    ]);
    setSource("");
    setFinding("");
    setNotice("Source-review record added. This is creator-entered evidence, not platform verification.");
  };

  const approve = () => {
    if (!canApprove) return;
    setApproved(true);
    setNotice("Draft approved after source review. Export is now available.");
    setStep("Approval");
  };

  const exportApproved = () => {
    if (!approved || !drafts[0]) return;
    const text = [
      "ADJACENT CINEMA — FILMSPONSOR EXPORT",
      `film: ${campaign.filmTitle || "—"}`,
      `approved: ${new Date().toISOString()}`,
      "",
      drafts[0].body,
      "",
      "Brand affinity is not sponsorship likelihood, eligibility, budget or ROI.",
      "No Qloo brands were substituted in this workspace.",
    ].join("\n");
    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "filmsponsor-approved.txt";
    a.click();
    URL.revokeObjectURL(url);
    setNotice("Approved material exported.");
  };

  const addOutreach = () => {
    if (!brand.trim()) return;
    setOutreach((prev) => [
      {
        id: uid("out"),
        at: new Date().toISOString(),
        brand: brand.trim(),
        channel,
        outcome,
        note: note.trim(),
      },
      ...prev,
    ]);
    setBrand("");
    setNote("");
    setNotice("Outreach recorded as an observation. Not a predicted conversion.");
  };

  const runDiscovery = async () => {
    setDiscovering(true);
    setNotice(null);
    try {
      await fetch("/api/health");
    } catch {
      /* still unavailable */
    }
    setDiscovering(false);
    setDiscoveryState("unavailable");
    setStep("Discovery");
    setNotice(
      "Live Qloo brand discovery is unavailable. Nothing was substituted. Affinity scores were not invented."
    );
  };

  return (
    <div>
      <section className="relative overflow-hidden border-b border-line">
        <div className="absolute inset-0 opacity-40">
          <PhotoFrame photo={photos.writing} className="h-full min-h-[320px]" credit={false} />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/85 to-ink/40" />
        <div className="relative mx-auto max-w-[1440px] px-4 py-16 md:px-8 md:py-24">
          <p className="type-kicker">FilmSponsor</p>
          <h1 className="font-display mt-3 max-w-[18ch] text-5xl leading-[0.92] md:text-7xl">
            A campaign dossier, not a CRM.
          </h1>
          <p className="mt-5 max-w-lg text-sm leading-relaxed text-paper-2">
            Intake, live discovery when configured, drafts, source review, approval, export, and
            manually recorded outreach. Brand affinity is not sponsorship likelihood.
          </p>
        </div>
      </section>

      <div className="border-b border-line">
        <ol className="mx-auto flex max-w-[1440px] gap-0 overflow-x-auto px-2 md:px-8" aria-label="Campaign stages">
          {STEPS.map((s, i) => {
            const state =
              s === "Discovery" && discoveryState === "unavailable"
                ? "unavailable"
                : s === "Approval" && !approved
                  ? drafts.length === 0 || reviews.length === 0
                    ? "locked"
                    : "ready"
                  : s === "Export" && !approved
                    ? "locked"
                    : null;
            return (
              <li key={s} className="flex-1 min-w-[7rem]">
                <button
                  type="button"
                  onClick={() => setStep(s)}
                  aria-current={step === s ? "step" : undefined}
                  className={cn(
                    "flex w-full flex-col border-b-2 px-2 py-3 text-left",
                    step === s ? "border-amber" : "border-transparent"
                  )}
                >
                  <span className="flex items-baseline justify-between gap-2">
                    <span className="font-mono text-[0.58rem] tracking-[0.16em] text-amber">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    {state && (
                      <span
                        className={cn(
                          "font-mono text-[0.5rem] tracking-[0.1em] uppercase",
                          state === "unavailable" && "text-warn",
                          state === "locked" && "text-dim",
                          state === "ready" && "text-sage"
                        )}
                      >
                        {state}
                      </span>
                    )}
                  </span>
                  <span className={cn("text-sm", step === s ? "text-paper" : "text-mute")}>
                    {s}
                  </span>
                </button>
              </li>
            );
          })}
        </ol>
      </div>

      {notice && (
        <div className="border-b border-amber/30 bg-amber/10">
          <p className="mx-auto max-w-[1440px] px-4 py-3 text-sm text-amber md:px-8">{notice}</p>
        </div>
      )}

      <div className="mx-auto grid max-w-[1440px] gap-10 px-4 py-12 md:grid-cols-12 md:px-8">
        <div className="md:col-span-8">
          {step === "Intake" && (
            <div className="space-y-7">
              <h2 className="font-display text-4xl">Campaign intake</h2>
              <Field label="Film title">
                <TextInput
                  value={campaign.filmTitle}
                  onChange={(e) => setCampaign({ ...campaign, filmTitle: e.target.value })}
                />
              </Field>
              <Field label="Logline">
                <TextArea
                  value={campaign.logline}
                  onChange={(e) => setCampaign({ ...campaign, logline: e.target.value })}
                />
              </Field>
              <div className="grid gap-6 sm:grid-cols-2">
                <Field label="Campaign goal">
                  <TextInput
                    value={campaign.goal}
                    onChange={(e) => setCampaign({ ...campaign, goal: e.target.value })}
                    placeholder="In-kind lab support, not cash forecast"
                  />
                </Field>
                <Field label="Territory">
                  <TextInput
                    value={campaign.territory}
                    onChange={(e) => setCampaign({ ...campaign, territory: e.target.value })}
                  />
                </Field>
              </div>
              <Field label="Notes">
                <TextArea
                  value={campaign.notes}
                  onChange={(e) => setCampaign({ ...campaign, notes: e.target.value })}
                />
              </Field>
              <button type="button" className="btn-primary" onClick={() => setStep("Discovery")}>
                Continue to discovery
              </button>
            </div>
          )}

          {step === "Discovery" && (
            <div>
              <h2 className="font-display text-4xl">Brand discovery</h2>
              <p className="mt-4 max-w-xl text-sm leading-relaxed text-mute">
                Discovery runs only against live Qloo when a backend key exists. This workspace will
                not invent brands, affinity scores, or eligibility.
              </p>
              <button
                type="button"
                className="btn-primary mt-8"
                onClick={runDiscovery}
                disabled={discovering}
              >
                {discovering ? "Requesting…" : "Request live discovery"}
              </button>
              {discoveryState === "unavailable" && (
                <div className="mt-8 border border-line p-6">
                  <p className="chip chip-warn">Unavailable</p>
                  <h3 className="font-display mt-4 text-3xl">No brands were substituted.</h3>
                  <p className="mt-3 text-sm leading-relaxed text-mute">
                    Without a Qloo key the discover route must remain empty. You may still write a
                    draft from your own knowledge, then record a source review before approval.
                  </p>
                </div>
              )}
            </div>
          )}

          {step === "Evidence" && (
            <div>
              <h2 className="font-display text-4xl">Evidence inspection</h2>
              <p className="mt-4 text-sm text-mute">
                Brand affinity, when present, is a cultural-similarity signal. It is not sponsorship
                likelihood, budget, availability or ROI.
              </p>
              <div className="mt-8 border border-dashed border-line-strong p-8">
                <p className="caption">No discovery payload · unavailable</p>
                <p className="mt-3 text-sm text-paper-2">
                  An empty evidence pane is the correct state. Sample brands would be a product
                  violation.
                </p>
              </div>
            </div>
          )}

          {step === "Draft" && (
            <div>
              <h2 className="font-display text-4xl">Sponsorship draft</h2>
              <Field label="Draft body" className="mt-6">
                <TextArea
                  value={draftBody}
                  onChange={(e) => setDraftBody(e.target.value)}
                  placeholder="A letter the filmmaker would actually send…"
                  className="min-h-[12rem]"
                />
              </Field>
              <button type="button" className="btn-primary mt-4" onClick={saveDraft}>
                Save version
              </button>
              <ul className="mt-8 divide-y divide-line border-y border-line">
                {drafts.length === 0 && (
                  <li className="py-6 text-sm text-mute">No versions yet.</li>
                )}
                {drafts.map((d) => (
                  <li key={d.id} className="py-4">
                    <p className="caption">
                      v{d.version} · {formatWhen(d.at)}
                    </p>
                    <p className="mt-2 line-clamp-3 text-sm text-paper-2">{d.body}</p>
                    <button
                      type="button"
                      className="btn-ghost mt-3"
                      onClick={() => setDraftBody(d.body)}
                    >
                      Load into editor
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {step === "Review" && (
            <div>
              <h2 className="font-display text-4xl">Official-source review</h2>
              <p className="mt-3 text-sm text-mute">
                You record what you checked. Adjacent does not independently verify a brand’s
                willingness to sponsor.
              </p>
              <div className="mt-6 grid gap-4">
                <Field label="Source">
                  <TextInput
                    value={source}
                    onChange={(e) => setSource(e.target.value)}
                    placeholder="Brand press page, Companies House, festival partner list…"
                  />
                </Field>
                <Field label="Finding">
                  <TextArea value={finding} onChange={(e) => setFinding(e.target.value)} />
                </Field>
                <button type="button" className="btn-amber self-start" onClick={addReview}>
                  Add review record
                </button>
              </div>
              <ul className="mt-8 space-y-4">
                {reviews.map((r) => (
                  <li key={r.id} className="border border-line p-4">
                    <p className="caption">{formatWhen(r.at)}</p>
                    <p className="mt-1 text-paper">{r.source}</p>
                    <p className="mt-2 text-sm text-mute">{r.finding}</p>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {step === "Approval" && (
            <div>
              <h2 className="font-display text-4xl">Approval</h2>
              <p className="mt-3 text-sm text-mute">
                Approval requires at least one draft and one source-review record. It is a considered
                act, not a toggle.
              </p>
              <div className="mt-8 border border-line p-8">
                {approved ? (
                  <>
                    <p className="chip chip-live">
                      <Check size={12} /> Approved
                    </p>
                    <p className="font-display mt-4 text-3xl">The dossier may leave the room.</p>
                  </>
                ) : (
                  <>
                    <p className="caption">
                      Drafts {drafts.length} · Reviews {reviews.length}
                    </p>
                    <button
                      type="button"
                      className="btn-primary mt-6"
                      disabled={!canApprove}
                      onClick={approve}
                    >
                      Approve current draft
                    </button>
                    {!canApprove && (
                      <p className="mt-3 text-sm text-dim">
                        Add a draft and a source review before approval is offered.
                      </p>
                    )}
                  </>
                )}
              </div>
            </div>
          )}

          {step === "Export" && (
            <div>
              <h2 className="font-display text-4xl">Export</h2>
              <p className="mt-3 text-sm text-mute">Only approved material can be exported.</p>
              <button
                type="button"
                className="btn-primary mt-8"
                disabled={!approved}
                onClick={exportApproved}
              >
                <Download size={16} />
                Export approved .txt
              </button>
            </div>
          )}

          {step === "Outreach" && (
            <div>
              <h2 className="font-display text-4xl">Outreach ledger</h2>
              <p className="mt-3 text-sm text-mute">
                Manually entered. Outcomes are observations, not model predictions.
              </p>
              <div className="mt-6 grid gap-4 sm:grid-cols-2">
                <Field label="Brand (your record)">
                  <TextInput value={brand} onChange={(e) => setBrand(e.target.value)} />
                </Field>
                <Field label="Channel">
                  <TextInput value={channel} onChange={(e) => setChannel(e.target.value)} />
                </Field>
                <Field label="Outcome">
                  <TextInput value={outcome} onChange={(e) => setOutcome(e.target.value)} />
                </Field>
                <Field label="Note">
                  <TextInput value={note} onChange={(e) => setNote(e.target.value)} />
                </Field>
              </div>
              <button type="button" className="btn-amber mt-4" onClick={addOutreach}>
                Record outreach
              </button>
              {outreach.length === 0 ? (
                <p className="mt-8 text-sm text-mute">
                  Empty on purpose. The next action is to record a real contact — or none.
                </p>
              ) : (
                <ul className="mt-8 divide-y divide-line border-y border-line">
                  {outreach.map((o) => (
                    <li key={o.id} className="py-4">
                      <p className="text-paper">
                        {o.brand} · {o.channel} · {o.outcome}
                      </p>
                      <p className="caption mt-1">{formatWhen(o.at)}</p>
                      {o.note && <p className="mt-2 text-sm text-mute">{o.note}</p>}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </div>

        <aside className="md:col-span-4">
          <PhotoFrame photo={photos.lanternStreet} className="aspect-[3/4]" />
          <div className="mt-6 border border-line p-5">
            <p className="type-kicker">Campaign</p>
            <p className="font-display mt-3 text-2xl">{campaign.filmTitle || "Untitled film"}</p>
            <p className="mt-2 text-sm text-mute">{campaign.goal || "No goal set"}</p>
            <dl className="mt-5 space-y-2 text-sm">
              <div className="flex justify-between">
                <dt className="caption">Stage</dt>
                <dd>
                  {idx + 1} / {STEPS.length}
                </dd>
              </div>
              <div className="flex justify-between">
                <dt className="caption">Drafts</dt>
                <dd>{drafts.length}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="caption">Reviews</dt>
                <dd>{reviews.length}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="caption">Approved</dt>
                <dd>{approved ? "yes" : "no"}</dd>
              </div>
            </dl>
          </div>
        </aside>
      </div>
    </div>
  );
}
