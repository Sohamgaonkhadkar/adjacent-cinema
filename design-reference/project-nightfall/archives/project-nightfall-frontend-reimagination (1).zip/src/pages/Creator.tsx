import { useEffect, useRef, useState } from "react";
import { ArrowRight, Plus, Trash2 } from "lucide-react";
import type {
  Experiment,
  FilmBrief,
  Observation,
  ObservationKind,
  EvaluationVerdict,
  RunStatus,
} from "../types";
import {
  FIXTURE_LABEL,
  analysisStages,
  saltLightBet,
  saltLightBrief,
  saltLightNodes,
  saltLightTestCard,
} from "../data/fixture";
import { photos } from "../data/photos";
import { PhotoFrame } from "../components/PhotoFrame";
import { Field, TextArea, TextInput } from "../components/Field";
import { CulturalFingerprint } from "../components/CulturalFingerprint";
import { PositioningArena, type ArenaSource } from "../components/PositioningArena";
import { TestCard } from "../components/TestCard";
import { ClaimChip, DataChip, ObservationChip, RunChip, VerdictChip } from "../components/ClaimChip";
import { loadExperiments, saveExperiments, uid, formatWhen } from "../lib/storage";
import { cn } from "../utils/cn";

type SectionId =
  | "film"
  | "investigation"
  | "fingerprint"
  | "arena"
  | "decision"
  | "test"
  | "archive";

const SECTIONS: { id: SectionId; label: string; needsRun: boolean }[] = [
  { id: "film", label: "Your film", needsRun: false },
  { id: "investigation", label: "Investigation", needsRun: false },
  { id: "fingerprint", label: "Cultural fingerprint", needsRun: true },
  { id: "arena", label: "Positioning arena", needsRun: false },
  { id: "decision", label: "Decision brief", needsRun: true },
  { id: "test", label: "Test card", needsRun: true },
  { id: "archive", label: "Archive", needsRun: false },
];

const emptyBrief: FilmBrief = {
  title: "",
  logline: "",
  genre: "",
  language: "",
  themes: "",
  comparables: [{ title: "", year: "" }],
  releaseGoal: "",
  location: "",
};

export function Creator({ fixtureIntent }: { fixtureIntent: boolean }) {
  const [brief, setBrief] = useState<FilmBrief>(fixtureIntent ? saltLightBrief : emptyBrief);
  const [status, setStatus] = useState<RunStatus>("idle");
  const [step, setStep] = useState(0);
  const [mode, setMode] = useState<"fixture" | "live" | null>(fixtureIntent ? "fixture" : null);
  const [card, setCard] = useState(saltLightTestCard);
  const [editingCard, setEditingCard] = useState(false);
  const [experiments, setExperiments] = useState<Experiment[]>([]);
  const [notice, setNotice] = useState<string | null>(null);
  const [obsKind, setObsKind] = useState<ObservationKind>("OBSERVED");
  const [obsNote, setObsNote] = useState("");
  const [evalVerdict, setEvalVerdict] = useState<EvaluationVerdict>("INCONCLUSIVE");
  const [evalNote, setEvalNote] = useState("");
  const [openExp, setOpenExp] = useState<string | null>(null);
  const [activeSection, setActiveSection] = useState<SectionId>("film");
  const ranRef = useRef(false);

  const completed = status === "completed";

  useEffect(() => {
    setExperiments(loadExperiments());
  }, []);

  useEffect(() => {
    if (!fixtureIntent || ranRef.current) return;
    ranRef.current = true;
    setMode("fixture");
    setStatus("running");
    setStep(0);
  }, [fixtureIntent]);

  useEffect(() => {
    if (status !== "running") return;
    if (step >= analysisStages.length) {
      setStatus("completed");
      setCard({
        ...saltLightTestCard,
        filmTitle: brief.title || saltLightTestCard.filmTitle,
      });
      return;
    }
    const t = window.setTimeout(() => setStep((s) => s + 1), 520);
    return () => window.clearTimeout(t);
  }, [status, step, brief.title]);

  useEffect(() => {
    const els = SECTIONS.map((s) => document.getElementById(s.id)).filter(Boolean) as HTMLElement[];
    if (!els.length) return;
    const io = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) setActiveSection(visible.target.id as SectionId);
      },
      { rootMargin: "-30% 0px -55% 0px", threshold: [0, 0.2, 0.5] }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  const persist = (next: Experiment[]) => {
    setExperiments(next);
    saveExperiments(next);
  };

  const scrollTo = (id: SectionId) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const startFixture = () => {
    setMode("fixture");
    setStatus("running");
    setStep(0);
    setNotice(null);
    scrollTo("investigation");
  };

  const startLive = async () => {
    if (!brief.title.trim()) {
      setNotice("A working title is required before a live investigation.");
      return;
    }
    setMode("live");
    setStatus("running");
    setStep(0);
    setNotice(null);
    scrollTo("investigation");
    try {
      // Same-origin /api proxy only — never a direct Render call, never a browser credential.
      const res = await fetch("/api/health");
      if (!res.ok) throw new Error("unhealthy");
      setStatus("unavailable");
      setNotice(
        "Backend reachable, but no live Qloo analysis was recorded for this session. Nothing was substituted. You may run the labelled fixture."
      );
    } catch {
      setStatus("unavailable");
      setNotice(
        "Live investigation requires the backend Qloo configuration. No silent fixture fallback occurred."
      );
    }
  };

  const savePlan = () => {
    if (!completed) return;
    const exp: Experiment = {
      id: uid("exp"),
      createdAt: new Date().toISOString(),
      filmTitle: brief.title || card.filmTitle,
      bet: saltLightBet.primary,
      testCard: card,
      dataStatus: mode === "live" ? "unavailable" : "fixture",
      observations: [],
      evaluations: [],
    };
    persist([exp, ...experiments]);
    setNotice("Plan saved to this browser’s archive. Saving does not run the experiment.");
    setOpenExp(exp.id);
    scrollTo("archive");
  };

  const appendObs = (id: string) => {
    if (!obsNote.trim()) return;
    const obs: Observation = {
      id: uid("obs"),
      at: new Date().toISOString(),
      kind: obsKind,
      note: obsNote.trim(),
    };
    persist(
      experiments.map((e) => (e.id === id ? { ...e, observations: [...e.observations, obs] } : e))
    );
    setObsNote("");
    setNotice("Observation appended. History is not rewritten.");
  };

  const appendEval = (id: string) => {
    if (!evalNote.trim()) return;
    const current = experiments.find((e) => e.id === id);
    const ev = {
      id: uid("eval"),
      at: new Date().toISOString(),
      verdict: evalVerdict,
      note: evalNote.trim(),
      supersedes: current?.evaluations.at(-1)?.id,
    };
    persist(
      experiments.map((e) => (e.id === id ? { ...e, evaluations: [...e.evaluations, ev] } : e))
    );
    setEvalNote("");
    setNotice("Evaluation recorded. Earlier verdicts remain on the timeline.");
  };

  const arenaSource: ArenaSource = {
    filmTitle: brief.title || (fixtureIntent ? saltLightBrief.title : ""),
    dataStatus: !completed ? "none" : mode === "live" ? "measured" : "fixture",
    runId: mode === "fixture" ? "fixture-run" : undefined,
    completed,
  };

  return (
    <div className="bg-ink">
      <header className="border-b border-line">
        <div className="mx-auto flex max-w-[1440px] flex-wrap items-end justify-between gap-4 px-4 py-8 md:px-8">
          <div>
            <p className="type-kicker">Creator Studio</p>
            <h1 className="font-display mt-2 text-4xl md:text-6xl">
              Position your film in its <span className="italic text-amber">cultural world.</span>
            </h1>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <RunChip status={status} />
            {mode === "fixture" && <DataChip status="fixture" />}
            {mode === "live" && !completed && status !== "running" && (
              <DataChip status="unavailable" />
            )}
          </div>
        </div>
      </header>

      <nav
        className="sticky top-[64px] z-40 border-b border-line bg-ink/95 backdrop-blur"
        aria-label="Creator journey"
      >
        <div className="mx-auto flex max-w-[1440px] gap-1 overflow-x-auto px-4 py-2 md:px-8">
          {SECTIONS.map((s, i) => (
            <button
              key={s.id}
              type="button"
              onClick={() => scrollTo(s.id)}
              aria-current={activeSection === s.id ? "true" : undefined}
              className={cn(
                "flex shrink-0 items-center gap-2 border-b-2 px-3 py-2 font-mono text-[0.62rem] tracking-[0.14em] uppercase transition-colors",
                activeSection === s.id
                  ? "border-amber text-paper"
                  : "border-transparent text-mute hover:text-paper-2",
                s.needsRun && !completed && "opacity-60"
              )}
            >
              <span className="text-amber">{String(i + 1).padStart(2, "0")}</span>
              {s.label}
            </button>
          ))}
        </div>
      </nav>

      {notice && (
        <div className="border-b border-amber/30 bg-amber/10">
          <p className="mx-auto max-w-[1440px] px-4 py-3 text-sm text-amber md:px-8">{notice}</p>
        </div>
      )}

      {/* 01 — YOUR FILM */}
      <section id="film" className="scroll-mt-36 border-b border-line">
        <Intake
          brief={brief}
          setBrief={setBrief}
          onFixture={() => {
            setBrief(saltLightBrief);
            setCard(saltLightTestCard);
            startFixture();
          }}
          onLive={startLive}
        />
      </section>

      {/* 02 — INVESTIGATION */}
      <section id="investigation" className="scroll-mt-36 border-b border-line">
        <div className="mx-auto max-w-[1440px] px-4 py-14 md:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="type-kicker">02 · Investigation</p>
              <h2 className="font-display mt-2 text-3xl md:text-5xl">
                {status === "running" && "The room is working."}
                {status === "unavailable" && "Live evidence is unavailable."}
                {status === "failed" && "The run failed."}
                {status === "insufficient" && "Not enough evidence."}
                {status === "cancelled" && "The run was interrupted."}
                {completed && "Investigation complete."}
                {status === "idle" && "No run yet."}
              </h2>
            </div>
            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                className="btn-primary"
                disabled={status === "running"}
                onClick={startFixture}
              >
                {completed ? "Re-run labelled fixture" : "Run labelled fixture"}
                <ArrowRight size={16} />
              </button>
              <button
                type="button"
                className="btn-ghost"
                disabled={status === "running"}
                onClick={startLive}
              >
                Attempt live analysis
              </button>
            </div>
          </div>

          {mode === "fixture" && status === "running" && (
            <p className="mt-3 text-sm text-amber">
              {FIXTURE_LABEL} · no live Qloo calls are being made.
            </p>
          )}

          <ol className="mt-10 grid gap-x-8 md:grid-cols-2">
            {analysisStages.map((s, i) => {
              const state =
                i < step ? "done" : i === step && status === "running" ? "now" : "wait";
              return (
                <li key={s.id} className="grid grid-cols-[4.5rem_1fr] gap-4 border-t border-line py-4">
                  <span
                    className={cn(
                      "font-mono text-xs tracking-[0.14em]",
                      state === "now" && "text-amber",
                      state === "done" && "text-sage",
                      state === "wait" && "text-dim"
                    )}
                  >
                    {state === "done" ? "DONE" : state === "now" ? "NOW" : "WAIT"}
                  </span>
                  <div>
                    <p className="text-paper">{s.label}</p>
                    <p className="mt-1 text-sm text-mute">{s.detail}</p>
                  </div>
                </li>
              );
            })}
          </ol>

          {(status === "unavailable" || status === "failed" || status === "cancelled") && (
            <div className="mt-8 max-w-2xl border border-line p-6">
              <p className="text-sm leading-relaxed text-paper-2">
                Failure is a legitimate terminal state. Nothing was substituted, and no fixture result
                was promoted to a measured one.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* 03 — CULTURAL FINGERPRINT */}
      <section id="fingerprint" className="scroll-mt-36 border-b border-line">
        <div className="mx-auto max-w-[1440px] px-4 py-14 md:px-8">
          <p className="type-kicker">03 · Cultural fingerprint</p>
          {completed ? (
            <>
              <h2 className="font-display mt-2 text-3xl md:text-5xl">
                {brief.title || "Your film"}
              </h2>
              <p className="mt-3 max-w-2xl text-sm text-mute">{FIXTURE_LABEL}</p>
              <div className="mt-8">
                <CulturalFingerprint nodes={saltLightNodes} filmTitle={brief.title || "Your film"} />
              </div>
            </>
          ) : (
            <Locked
              title="The fingerprint waits for evidence."
              body="A completed investigation places this film at the centre with the cohorts it actually returned. No graph is drawn before then."
              action="Go to investigation"
              onAction={() => scrollTo("investigation")}
            />
          )}
        </div>
      </section>

      {/* 04 — POSITIONING ARENA */}
      <section id="arena" className="scroll-mt-36 border-b border-line bg-ink-3/40">
        <div className="mx-auto max-w-[1440px] px-4 py-14 md:px-8">
          <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="type-kicker">04 · Positioning arena</p>
              <h2 className="font-display mt-2 text-3xl md:text-5xl">
                Compare defensible directions.
              </h2>
            </div>
            <p className="max-w-md text-sm leading-relaxed text-mute">
              Concept preview until the strategy engine ships. Runs on an isolated sample context so
              no sample evidence is ever presented beneath your film’s name.
            </p>
          </div>
          <PositioningArena source={arenaSource} />
        </div>
      </section>

      {/* 05 — DECISION BRIEF */}
      <section id="decision" className="scroll-mt-36 border-b border-line">
        <div className="mx-auto max-w-[1440px] px-4 py-14 md:px-8">
          <p className="type-kicker">05 · Decision brief</p>
          {completed ? (
            <div className="mt-6 grid gap-10 lg:grid-cols-12">
              <div className="lg:col-span-7">
                <ClaimChip kind="HYPOTHESIS" />
                <h2 className="font-display mt-6 text-3xl leading-[1.05] md:text-5xl">
                  {saltLightBet.primary}
                </h2>
                <p className="mt-6 text-sm leading-relaxed text-paper-2">{saltLightBet.rationale}</p>
                {saltLightBet.runnerUp && (
                  <p className="mt-6 text-sm text-mute">
                    <span className="text-amber">Runner-up · </span>
                    {saltLightBet.runnerUp}
                  </p>
                )}
              </div>
              <div className="lg:col-span-5">
                <PhotoFrame photo={photos.analogDesk} className="aspect-[4/5]" />
                <div className="mt-6 border border-line p-5">
                  <p className="type-kicker">Limitations</p>
                  <ul className="mt-4 space-y-3">
                    {saltLightBet.limitations.map((l) => (
                      <li key={l} className="text-sm leading-relaxed text-mute">
                        {l}
                      </li>
                    ))}
                  </ul>
                  <p className="caption mt-5">Subject · {brief.title || "—"}</p>
                </div>
              </div>
            </div>
          ) : (
            <Locked
              title="The Programme Bet needs a run."
              body="An interpretation is written over the evidence that produced it. Until an investigation completes, there is nothing to interpret."
              action="Go to investigation"
              onAction={() => scrollTo("investigation")}
            />
          )}
        </div>
      </section>

      {/* 06 — TEST CARD */}
      <section id="test" className="scroll-mt-36 border-b border-line">
        <div className="mx-auto max-w-[1440px] px-4 py-14 md:px-8">
          <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="type-kicker">06 · Test card</p>
              <h2 className="font-display mt-2 text-3xl md:text-5xl">A plan, not a result.</h2>
            </div>
            <button
              type="button"
              className="btn-primary"
              disabled={!completed}
              onClick={savePlan}
              title={completed ? "Save a planned experiment" : "Requires a completed investigation"}
            >
              Save planned experiment
            </button>
          </div>
          {completed ? (
            <TestCard
              card={card}
              editing={editingCard}
              onChange={setCard}
              onToggleEdit={() => setEditingCard((v) => !v)}
              bet={saltLightBet.primary}
              runId={mode === "fixture" ? "fixture-run" : undefined}
            />
          ) : (
            <Locked
              title="No card to edit yet."
              body="The Test Card is drafted from a completed investigation, then yours to edit and export. Saving a plan never means the experiment has run."
              action="Go to investigation"
              onAction={() => scrollTo("investigation")}
            />
          )}
        </div>
      </section>

      {/* 07 — ARCHIVE */}
      <section id="archive" className="scroll-mt-36">
        <Archive
          experiments={experiments}
          openExp={openExp}
          setOpenExp={setOpenExp}
          obsKind={obsKind}
          setObsKind={setObsKind}
          obsNote={obsNote}
          setObsNote={setObsNote}
          evalVerdict={evalVerdict}
          setEvalVerdict={setEvalVerdict}
          evalNote={evalNote}
          setEvalNote={setEvalNote}
          appendObs={appendObs}
          appendEval={appendEval}
        />
      </section>
    </div>
  );
}

function Locked({
  title,
  body,
  action,
  onAction,
}: {
  title: string;
  body: string;
  action: string;
  onAction: () => void;
}) {
  return (
    <div className="mt-6 flex flex-col items-start gap-6 border border-dashed border-line-strong p-8 md:flex-row md:items-center md:justify-between">
      <div className="max-w-xl">
        <p className="chip chip-warn">Requires completed analysis</p>
        <h3 className="font-display mt-4 text-3xl">{title}</h3>
        <p className="mt-3 text-sm leading-relaxed text-mute">{body}</p>
      </div>
      <button type="button" className="btn-ghost shrink-0" onClick={onAction}>
        {action}
        <ArrowRight size={14} />
      </button>
    </div>
  );
}

function Intake({
  brief,
  setBrief,
  onFixture,
  onLive,
}: {
  brief: FilmBrief;
  setBrief: (b: FilmBrief) => void;
  onFixture: () => void;
  onLive: () => void;
}) {
  const set = (patch: Partial<FilmBrief>) => setBrief({ ...brief, ...patch });
  const canInvestigate = brief.title.trim().length > 0;

  return (
    <div className="mx-auto grid max-w-[1440px] gap-10 px-4 py-14 md:grid-cols-12 md:px-8">
      <div className="md:col-span-7">
        <div className="border border-line p-5 md:p-8">
          <p className="type-kicker">The film</p>
          <p className="mt-2 text-xs text-dim">
            Only the title is required. Everything else strengthens the evidence.
          </p>
          <div className="mt-8 space-y-7">
            <Field label="Working title *">
              <TextInput
                required
                value={brief.title}
                onChange={(e) => set({ title: e.target.value })}
                placeholder="Salt Light"
              />
            </Field>
            <Field
              label="Logline"
              hint="Used as context, never as a substitute for resolved entities."
            >
              <TextArea
                value={brief.logline}
                onChange={(e) => set({ logline: e.target.value })}
                placeholder="A teenage projectionist inherits her father's last reel…"
              />
            </Field>
            <div className="grid gap-6 sm:grid-cols-2">
              <Field label="Genre">
                <TextInput value={brief.genre} onChange={(e) => set({ genre: e.target.value })} />
              </Field>
              <Field label="Language">
                <TextInput
                  value={brief.language}
                  onChange={(e) => set({ language: e.target.value })}
                />
              </Field>
            </div>
          </div>
        </div>

        <div className="mt-6 border border-line p-5 md:p-8">
          <p className="type-kicker">Cultural references</p>
          <div className="mt-8 space-y-7">
            <Field
              label="Themes"
              hint="Comma-separated concepts. Resolved as tags, never as extra film titles."
            >
              <TextInput
                value={brief.themes}
                onChange={(e) => set({ themes: e.target.value })}
                placeholder="inheritance, analog memory"
              />
            </Field>
            <div>
              <span className="field-label">Comparable works</span>
              <p className="mb-4 text-xs text-dim">
                Title and year where known. Unresolved titles stay unresolved.
              </p>
              <ul className="space-y-3">
                {brief.comparables.map((c, i) => (
                  <li key={i} className="grid grid-cols-1 gap-2 sm:grid-cols-[1fr_6rem_2.5rem]">
                    <TextInput
                      aria-label={`Comparable title ${i + 1}`}
                      placeholder="Aftersun"
                      value={c.title}
                      onChange={(e) => {
                        const next = [...brief.comparables];
                        next[i] = { ...c, title: e.target.value };
                        set({ comparables: next });
                      }}
                    />
                    <TextInput
                      aria-label={`Year ${i + 1}`}
                      placeholder="2022"
                      value={c.year}
                      onChange={(e) => {
                        const next = [...brief.comparables];
                        next[i] = { ...c, year: e.target.value };
                        set({ comparables: next });
                      }}
                    />
                    <button
                      type="button"
                      className="flex h-10 items-center justify-center text-mute hover:text-blood"
                      aria-label="Remove comparable"
                      onClick={() =>
                        set({ comparables: brief.comparables.filter((_, j) => j !== i) })
                      }
                    >
                      <Trash2 size={14} />
                    </button>
                  </li>
                ))}
              </ul>
              <button
                type="button"
                className="btn-ghost mt-4"
                onClick={() => set({ comparables: [...brief.comparables, { title: "", year: "" }] })}
              >
                <Plus size={14} />
                Add reference
              </button>
            </div>
          </div>
        </div>

        <div className="mt-6 border border-line p-5 md:p-8">
          <p className="type-kicker">Release context</p>
          <div className="mt-8 grid gap-6 sm:grid-cols-2">
            <Field label="Release goal">
              <TextInput
                value={brief.releaseGoal}
                onChange={(e) => set({ releaseGoal: e.target.value })}
                placeholder="Festival, then limited theatrical"
              />
            </Field>
            <Field
              label="Location (optional)"
              hint="Enables geography only when the run returns usable place data."
            >
              <TextInput
                value={brief.location}
                onChange={(e) => set({ location: e.target.value })}
                placeholder="Brighton, United Kingdom"
              />
            </Field>
          </div>
        </div>

        <div className="mt-8 flex flex-wrap gap-3">
          <button type="button" className="btn-primary" disabled={!canInvestigate} onClick={onFixture}>
            Run labelled fixture
            <ArrowRight size={16} />
          </button>
          <button type="button" className="btn-ghost" disabled={!canInvestigate} onClick={onLive}>
            Attempt live analysis
          </button>
          <button
            type="button"
            className="btn-ghost"
            onClick={() => setBrief(saltLightBrief)}
          >
            Load Salt Light brief
          </button>
        </div>
      </div>

      <aside className="md:col-span-5">
        <PhotoFrame photo={photos.screenplay} className="aspect-[4/5]" />
        <div className="mt-6 border border-line p-5">
          <p className="type-kicker">Dossier summary</p>
          <dl className="mt-4 space-y-3 text-sm">
            <Row k="Title" v={brief.title || "—"} />
            <Row k="Genre / lang." v={`${brief.genre || "—"} · ${brief.language || "—"}`} />
            <Row
              k="Comparables"
              v={brief.comparables.filter((c) => c.title).map((c) => c.title).join(", ") || "—"}
            />
            <Row k="Location" v={brief.location || "not set"} />
          </dl>
          <p className="caption mt-6">
            Live never becomes fixture silently. Fixture runs stay labelled at every layer.
          </p>
        </div>
      </aside>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between gap-4 border-b border-line pb-2">
      <dt className="caption">{k}</dt>
      <dd className="text-right text-paper-2">{v}</dd>
    </div>
  );
}

function Archive({
  experiments,
  openExp,
  setOpenExp,
  obsKind,
  setObsKind,
  obsNote,
  setObsNote,
  evalVerdict,
  setEvalVerdict,
  evalNote,
  setEvalNote,
  appendObs,
  appendEval,
}: {
  experiments: Experiment[];
  openExp: string | null;
  setOpenExp: (id: string | null) => void;
  obsKind: ObservationKind;
  setObsKind: (k: ObservationKind) => void;
  obsNote: string;
  setObsNote: (s: string) => void;
  evalVerdict: EvaluationVerdict;
  setEvalVerdict: (v: EvaluationVerdict) => void;
  evalNote: string;
  setEvalNote: (s: string) => void;
  appendObs: (id: string) => void;
  appendEval: (id: string) => void;
}) {
  const current =
    experiments.find((e) => e.id === openExp) ?? experiments[0] ?? null;

  return (
    <section className="mx-auto max-w-[1440px] px-4 py-14 md:px-8">
      <p className="type-kicker">07 · Experiment archive</p>
      <h2 className="font-display mt-2 text-3xl md:text-5xl">A living history of decisions.</h2>
      <p className="mt-3 max-w-2xl text-sm text-mute">
        Plans, observations and evaluations remain distinct. A later verdict does not overwrite the
        earlier one.
      </p>

      {experiments.length === 0 ? (
        <div className="mt-12 border border-line px-6 py-16 text-center">
          <p className="font-display text-3xl">The archive is empty.</p>
          <p className="mx-auto mt-3 max-w-md text-sm text-mute">
            Save a Test Card from a completed investigation to begin a record in this browser.
            Demonstration history is never mixed into your workspace unless you save it.
          </p>
        </div>
      ) : (
        <div className="mt-10 grid gap-8 lg:grid-cols-12">
          <ul className="lg:col-span-4">
            {experiments.map((e) => (
              <li key={e.id}>
                <button
                  type="button"
                  onClick={() => setOpenExp(e.id)}
                  className={cn(
                    "w-full border-b border-line py-4 text-left",
                    current?.id === e.id ? "text-paper" : "text-mute"
                  )}
                >
                  <p className="font-display text-2xl">{e.filmTitle}</p>
                  <p className="caption mt-1">
                    {formatWhen(e.createdAt)} · {e.dataStatus}
                  </p>
                </button>
              </li>
            ))}
          </ul>
          {current && (
            <div className="lg:col-span-8">
              <div className="flex flex-wrap gap-2">
                <DataChip status={current.dataStatus} />
                {current.evaluations.at(-1) && (
                  <VerdictChip verdict={current.evaluations.at(-1)!.verdict} />
                )}
              </div>
              <h3 className="font-display mt-4 text-3xl">{current.bet}</h3>
              <ol className="mt-8 border-l border-line pl-6">
                <li className="relative pb-8">
                  <span className="absolute -left-[31px] top-1 h-2 w-2 rounded-full bg-amber" />
                  <p className="caption">Original decision · {formatWhen(current.createdAt)}</p>
                  <p className="mt-2 text-sm text-paper-2">{current.testCard.hypothesis}</p>
                </li>
                {current.observations.map((o) => (
                  <li key={o.id} className="relative pb-8">
                    <span className="absolute -left-[31px] top-1 h-2 w-2 rounded-full bg-paper-2" />
                    <div className="flex flex-wrap items-center gap-2">
                      <ObservationChip kind={o.kind} />
                      <span className="caption">{formatWhen(o.at)}</span>
                    </div>
                    <p className="mt-2 text-sm text-paper-2">{o.note}</p>
                  </li>
                ))}
                {current.evaluations.map((ev) => (
                  <li key={ev.id} className="relative pb-8">
                    <span className="absolute -left-[31px] top-1 h-2 w-2 rounded-full bg-blood" />
                    <div className="flex flex-wrap items-center gap-2">
                      <VerdictChip verdict={ev.verdict} />
                      <span className="caption">{formatWhen(ev.at)}</span>
                    </div>
                    <p className="mt-2 text-sm text-paper-2">{ev.note}</p>
                    {ev.supersedes && (
                      <p className="caption mt-1">
                        Supersedes {ev.supersedes} without rewriting it.
                      </p>
                    )}
                  </li>
                ))}
              </ol>

              <div className="mt-4 grid gap-6 border border-line p-5 md:grid-cols-2">
                <div>
                  <p className="type-kicker">Append observation</p>
                  <label className="mt-4 block">
                    <span className="field-label">Kind</span>
                    <select
                      className="field-input"
                      value={obsKind}
                      onChange={(e) => setObsKind(e.target.value as ObservationKind)}
                    >
                      {["OBSERVED", "PARTIAL", "MISSING", "UNAVAILABLE", "FAILED"].map((k) => (
                        <option key={k} value={k} className="bg-ink">
                          {k}
                        </option>
                      ))}
                    </select>
                  </label>
                  <Field label="Note" className="mt-4">
                    <TextArea value={obsNote} onChange={(e) => setObsNote(e.target.value)} />
                  </Field>
                  <button
                    type="button"
                    className="btn-amber mt-4"
                    onClick={() => appendObs(current.id)}
                  >
                    Record observation
                  </button>
                </div>
                <div>
                  <p className="type-kicker">Record evaluation</p>
                  <label className="mt-4 block">
                    <span className="field-label">Verdict</span>
                    <select
                      className="field-input"
                      value={evalVerdict}
                      onChange={(e) => setEvalVerdict(e.target.value as EvaluationVerdict)}
                    >
                      {["SUPPORTED", "CONTRADICTED", "INCONCLUSIVE"].map((k) => (
                        <option key={k} value={k} className="bg-ink">
                          {k}
                        </option>
                      ))}
                    </select>
                  </label>
                  <Field label="Note" className="mt-4">
                    <TextArea value={evalNote} onChange={(e) => setEvalNote(e.target.value)} />
                  </Field>
                  <button
                    type="button"
                    className="btn-amber mt-4"
                    onClick={() => appendEval(current.id)}
                  >
                    Record evaluation
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </section>
  );
}
