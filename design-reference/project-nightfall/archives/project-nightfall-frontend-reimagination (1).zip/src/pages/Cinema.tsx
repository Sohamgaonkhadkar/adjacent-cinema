import { useEffect, useState } from "react";
import { ArrowRight, Plus, Trash2 } from "lucide-react";
import type { CinemaBrief, CinemaProgrammeEntry, RunStatus } from "../types";
import {
  FIXTURE_LABEL,
  analysisStages,
  cinemaBet,
  cinemaBrief as sampleBrief,
  cinemaTestCard,
  saltLightNodes,
} from "../data/fixture";
import { photos } from "../data/photos";
import { PhotoFrame } from "../components/PhotoFrame";
import { Field, TextInput } from "../components/Field";
import { CulturalFingerprint } from "../components/CulturalFingerprint";
import { TestCard } from "../components/TestCard";
import { ClaimChip, DataChip, RunChip } from "../components/ClaimChip";
import { cn } from "../utils/cn";

const emptyProgramme: CinemaProgrammeEntry[] = [
  { title: "", year: "", note: "" },
  { title: "", year: "", note: "" },
  { title: "", year: "", note: "" },
];

type ChapterId = "cinema" | "programme" | "cultural-field" | "opportunity" | "test";

const CHAPTERS: { id: ChapterId; label: string; needsRun: boolean }[] = [
  { id: "cinema", label: "Cinema", needsRun: false },
  { id: "programme", label: "Programme", needsRun: false },
  { id: "cultural-field", label: "Cultural field", needsRun: true },
  { id: "opportunity", label: "Opportunity", needsRun: true },
  { id: "test", label: "Test", needsRun: true },
];

export function Cinema() {
  const [brief, setBrief] = useState<CinemaBrief>({
    venue: "",
    city: "",
    programme: emptyProgramme,
  });
  const [status, setStatus] = useState<RunStatus>("idle");
  const [step, setStep] = useState(0);
  const [selected, setSelected] = useState(0);
  const [editingCard, setEditingCard] = useState(false);
  const [card, setCard] = useState(cinemaTestCard);
  const [mode, setMode] = useState<"fixture" | "live" | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [chapter, setChapter] = useState<ChapterId>("cinema");

  const completed = status === "completed";

  useEffect(() => {
    if (status !== "running") return;
    if (step >= analysisStages.length) {
      setStatus("completed");
      return;
    }
    const t = window.setTimeout(() => setStep((s) => s + 1), 480);
    return () => window.clearTimeout(t);
  }, [status, step]);

  useEffect(() => {
    const els = CHAPTERS.map((c) => document.getElementById(c.id)).filter(Boolean) as HTMLElement[];
    if (!els.length) return;
    const io = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) setChapter(visible.target.id as ChapterId);
      },
      { rootMargin: "-30% 0px -55% 0px", threshold: [0, 0.2, 0.5] }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  const goTo = (id: ChapterId) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });

  const startFixture = () => {
    setBrief(sampleBrief);
    setMode("fixture");
    setStatus("running");
    setStep(0);
    setNotice(null);
    setCard(cinemaTestCard);
    goTo("programme");
  };

  const startLive = async () => {
    if (!brief.venue.trim() || !brief.city.trim()) {
      setNotice("Venue and city are required before a live analysis.");
      return;
    }
    setMode("live");
    setStatus("running");
    setStep(0);
    setNotice(null);
    goTo("programme");
    try {
      // Same-origin /api proxy only — never a direct Render call.
      await fetch("/api/health");
      setStatus("unavailable");
      setNotice(
        "Backend reachable, but no live Cinema run was recorded. No programme map or cohort was invented to fill the space."
      );
    } catch {
      setStatus("unavailable");
      setNotice(
        "The backend could not be reached. Fixture data was not substituted. You may run the labelled cinema demonstration."
      );
    }
  };

  const programme = brief.programme.filter((p) => p.title.trim());

  return (
    <div>
      {/* CHAPTER — CINEMA */}
      <section id="cinema" className="scroll-mt-36 relative min-h-[70vh] overflow-hidden">
        <div className="absolute inset-0">
          <PhotoFrame photo={photos.cinemaCurtain} className="h-full" credit={false} priority />
          <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/55 to-ink/30" />
        </div>
        <div className="relative z-10 mx-auto flex min-h-[70vh] max-w-[1440px] flex-col justify-end px-4 pb-12 pt-28 md:px-8">
          <p className="type-kicker">Cinema Mode</p>
          <h1 className="font-display mt-4 max-w-[16ch] text-5xl leading-[0.92] md:text-7xl">
            A programmer’s cultural atlas.
          </h1>
          <p className="mt-5 max-w-lg text-sm leading-relaxed text-paper-2 md:text-base">
            Venue, city, a programme of films. Curation rather than a poster wall. Geography only
            when coordinates actually exist.
          </p>
          <p className="caption mt-6">Photo · {photos.cinemaCurtain.credit} / Pexels</p>
        </div>
      </section>

      <nav
        className="sticky top-[64px] z-40 border-b border-line bg-ink/95 backdrop-blur"
        aria-label="Cinema chapters"
      >
        <div className="mx-auto flex max-w-[1440px] gap-1 overflow-x-auto px-4 py-2 md:px-8">
          {CHAPTERS.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => goTo(c.id)}
              aria-current={chapter === c.id ? "true" : undefined}
              className={cn(
                "shrink-0 border-b-2 px-4 py-2 font-mono text-[0.62rem] tracking-[0.16em] uppercase transition-colors",
                chapter === c.id
                  ? "border-amber text-paper"
                  : "border-transparent text-mute hover:text-paper-2",
                c.needsRun && !completed && "opacity-60"
              )}
            >
              {c.label}
            </button>
          ))}
        </div>
      </nav>

      {notice && (
        <div className="border-b border-amber/30 bg-amber/10">
          <p className="mx-auto max-w-[1440px] px-4 py-3 text-sm text-amber md:px-8">{notice}</p>
        </div>
      )}

      <section className="mx-auto grid max-w-[1440px] gap-10 px-4 py-16 md:grid-cols-12 md:px-8">
        <div className="md:col-span-5">
          <p className="type-kicker">House notes</p>
          <h2 className="font-display mt-3 text-3xl md:text-4xl">The desk</h2>
          <div className="mt-8 space-y-6">
            <Field label="Venue">
              <TextInput
                value={brief.venue}
                onChange={(e) => setBrief({ ...brief, venue: e.target.value })}
                placeholder="The Light House"
              />
            </Field>
            <Field label="City">
              <TextInput
                value={brief.city}
                onChange={(e) => setBrief({ ...brief, city: e.target.value })}
                placeholder="Brighton"
              />
            </Field>
          </div>
          <div className="mt-8 flex flex-wrap gap-3">
            <button type="button" className="btn-primary" onClick={startFixture}>
              Run labelled fixture
              <ArrowRight size={16} />
            </button>
            <button type="button" className="btn-ghost" onClick={startLive}>
              Attempt live analysis
            </button>
          </div>
          <div className="mt-6 flex items-center gap-2">
            <RunChip status={status} />
            {mode === "fixture" && <DataChip status="fixture" />}
            {mode === "live" && !completed && status !== "running" && (
              <DataChip status="unavailable" />
            )}
          </div>
        </div>
        <div className="md:col-span-7">
          <p className="field-label">Programme</p>
          <p className="mb-4 text-xs text-dim">
            Titles and years. Photography here is atmospheric — not official artwork for these films.
          </p>
          <ul className="space-y-3">
            {brief.programme.map((row, i) => (
              <li key={i} className="grid grid-cols-1 gap-2 sm:grid-cols-[1fr_5.5rem_1fr_2.5rem]">
                <TextInput
                  aria-label={`Film title ${i + 1}`}
                  placeholder="Aftersun"
                  value={row.title}
                  onChange={(e) => {
                    const next = [...brief.programme];
                    next[i] = { ...row, title: e.target.value };
                    setBrief({ ...brief, programme: next });
                  }}
                />
                <TextInput
                  aria-label={`Year ${i + 1}`}
                  placeholder="2022"
                  value={row.year}
                  onChange={(e) => {
                    const next = [...brief.programme];
                    next[i] = { ...row, year: e.target.value };
                    setBrief({ ...brief, programme: next });
                  }}
                />
                <TextInput
                  aria-label={`Note ${i + 1}`}
                  placeholder="Curatorial note"
                  value={row.note}
                  onChange={(e) => {
                    const next = [...brief.programme];
                    next[i] = { ...row, note: e.target.value };
                    setBrief({ ...brief, programme: next });
                  }}
                />
                <button
                  type="button"
                  className="text-mute hover:text-blood"
                  aria-label="Remove title"
                  onClick={() =>
                    setBrief({ ...brief, programme: brief.programme.filter((_, j) => j !== i) })
                  }
                >
                  <Trash2 size={14} />
                </button>
              </li>
            ))}
          </ul>
          <button
            type="button"
            className="btn-ghost mt-4"
            onClick={() =>
              setBrief({
                ...brief,
                programme: [...brief.programme, { title: "", year: "", note: "" }],
              })
            }
          >
            <Plus size={14} />
            Add title
          </button>
        </div>
      </section>

      {/* CHAPTER — PROGRAMME */}
      <section id="programme" className="scroll-mt-36 border-t border-line bg-ink-2">
        <div className="mx-auto max-w-[1440px] px-4 py-14 md:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="type-kicker">Programme · contact sheet</p>
              <h2 className="font-display mt-2 text-3xl md:text-5xl">
                The programme as a strip, not a store.
              </h2>
            </div>
            <div className="flex flex-wrap gap-3">
              {status === "running" && <RunChip status="running" />}
              {mode === "fixture" && status === "running" && (
                <span className="chip chip-fixture">{FIXTURE_LABEL}</span>
              )}
            </div>
          </div>

          {status === "running" && (
            <ol className="mt-8 grid gap-x-8 md:grid-cols-2">
              {analysisStages.map((s, i) => (
                <li key={s.id} className="flex justify-between border-t border-line py-3 text-sm">
                  <span>{s.label}</span>
                  <span className="font-mono text-xs text-amber">
                    {i < step ? "DONE" : i === step ? "NOW" : "WAIT"}
                  </span>
                </li>
              ))}
            </ol>
          )}

          {status === "unavailable" && (
            <div className="mt-8 border border-dashed border-line-strong p-6">
              <p className="chip chip-warn">Unavailable</p>
              <p className="mt-3 text-sm text-paper-2">
                No map or cohort was drawn to hide the gap. A fixture run is optional and labelled.
              </p>
            </div>
          )}

          <p className="mt-10 max-w-xl text-sm text-mute">
            Images are atmospheric references. They are not posters, stills, or rights-cleared
            artwork for the titles listed.
          </p>

          {programme.length === 0 ? (
            <p className="mt-6 text-sm text-dim">
              No titles entered yet. The contact sheet appears once the programme has entries.
            </p>
          ) : (
            <div className="mt-6 flex gap-3 overflow-x-auto pb-4">
              {programme.map((p, i) => (
                <button
                  key={`${p.title}-${i}`}
                  type="button"
                  onClick={() => setSelected(i)}
                  aria-pressed={selected === i}
                  className={cn(
                    "w-44 shrink-0 text-left",
                    selected === i ? "opacity-100" : "opacity-70 hover:opacity-100"
                  )}
                >
                  <PhotoFrame
                    photo={
                      [photos.cinemaSeats, photos.urbanPuddle, photos.columns, photos.soho][i % 4]
                    }
                    className="aspect-[3/4]"
                    credit={false}
                    gate
                  />
                  <p className="mt-3 font-display text-xl">{p.title}</p>
                  <p className="caption mt-1">
                    {p.year} · {p.note || "no note"}
                  </p>
                </button>
              ))}
            </div>
          )}
          {programme[selected] && (
            <p className="mt-2 text-sm text-paper-2">
              Selected · {programme[selected].title} ({programme[selected].year}) —{" "}
              {programme[selected].note || "no curatorial note yet"}
            </p>
          )}
        </div>
      </section>

      {/* CHAPTER — CULTURAL FIELD */}
      <section id="cultural-field" className="scroll-mt-36 border-t border-line">
        <div className="mx-auto max-w-[1440px] px-4 py-14 md:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="type-kicker">Cultural field</p>
              <h2 className="font-display mt-2 text-4xl md:text-5xl">Returned worlds</h2>
            </div>
            {completed && <span className="chip chip-fixture">Fixture</span>}
          </div>

          {completed ? (
            <>
              <div className="mt-8">
                <CulturalFingerprint
                  nodes={saltLightNodes}
                  filmTitle={brief.venue || sampleBrief.venue}
                />
              </div>
              <div className="mt-10 grid gap-8 border border-line p-6 md:grid-cols-2">
                <div>
                  <p className="type-kicker">Geography</p>
                  <h3 className="font-display mt-3 text-3xl">City context without a fake heat map.</h3>
                  <p className="mt-4 text-sm leading-relaxed text-mute">
                    {brief.city || sampleBrief.city} is recorded as venue context. This fixture does
                    not include coordinates, so no choropleth, pins or attendance surface is
                    rendered.
                  </p>
                </div>
                <div className="flex min-h-[200px] items-end border border-dashed border-line-strong p-4">
                  <p className="caption">Map withheld · insufficient geographic evidence</p>
                </div>
              </div>
            </>
          ) : (
            <Locked
              title="No cultural field yet."
              body="Ranked cohorts, rejected worlds and geographic evidence appear only after a completed run. Empty is not a graph."
              action="Run labelled fixture"
              onAction={startFixture}
            />
          )}
        </div>
      </section>

      {/* CHAPTER — OPPORTUNITY */}
      <section id="opportunity" className="scroll-mt-36 border-t border-line bg-ink-2">
        <div className="mx-auto max-w-[1440px] px-4 py-14 md:px-8">
          <p className="type-kicker">Opportunity · programming direction</p>
          {completed ? (
            <div className="mt-6 grid gap-10 md:grid-cols-12">
              <div className="md:col-span-7">
                <ClaimChip kind="HYPOTHESIS" />
                <h2 className="font-display mt-5 text-3xl leading-tight md:text-5xl">
                  {cinemaBet.primary}
                </h2>
                <p className="mt-5 text-sm leading-relaxed text-paper-2">{cinemaBet.rationale}</p>
                <ul className="mt-6 space-y-3">
                  {cinemaBet.limitations.map((l) => (
                    <li key={l} className="text-sm text-mute">
                      — {l}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="md:col-span-5">
                <PhotoFrame photo={photos.cinemaAisle} className="aspect-[4/5]" />
              </div>
            </div>
          ) : (
            <Locked
              title="No programming direction yet."
              body="The proposed direction is an interpretation written over ranked cohorts. Without a run there is nothing to interpret."
              action="Run labelled fixture"
              onAction={startFixture}
            />
          )}
        </div>
      </section>

      {/* CHAPTER — TEST */}
      <section id="test" className="scroll-mt-36 border-t border-line">
        <div className="mx-auto max-w-[1440px] px-4 py-14 md:px-8">
          <p className="type-kicker mb-6">Test · cinema test card</p>
          {completed ? (
            <TestCard
              card={card}
              editing={editingCard}
              onChange={setCard}
              onToggleEdit={() => setEditingCard((v) => !v)}
              bet={cinemaBet.primary}
            />
          ) : (
            <Locked
              title="No Test Card yet."
              body="The cinema Test Card is drafted from the programming direction and editable before it is saved. Export stays available from there."
              action="Run labelled fixture"
              onAction={startFixture}
            />
          )}
        </div>
      </section>
    </div>
  );
}

function Locked({
  title,
  body,
  action,
  onAction,
}: {
  title: string;
  body: string;
  action: string;
  onAction: () => void;
}) {
  return (
    <div className="mt-6 flex flex-col items-start gap-6 border border-dashed border-line-strong p-8 md:flex-row md:items-center md:justify-between">
      <div className="max-w-xl">
        <p className="chip chip-warn">Requires completed analysis</p>
        <h3 className="font-display mt-4 text-3xl">{title}</h3>
        <p className="mt-3 text-sm leading-relaxed text-mute">{body}</p>
      </div>
      <button type="button" className="btn-ghost shrink-0" onClick={onAction}>
        {action}
        <ArrowRight size={14} />
      </button>
    </div>
  );
}
