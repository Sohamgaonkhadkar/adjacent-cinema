import { useMemo, useState } from "react";
import { ArrowRight, Lock, Snowflake } from "lucide-react";
import type { ReactNode } from "react";
import { strategies, previewIndex, suggestStrategy, type Priorities } from "../data/multiverse";
import { photos, type Photo } from "../data/photos";
import { PhotoFrame } from "./PhotoFrame";
import { ClaimChip, DataChip } from "./ClaimChip";
import { cn } from "../utils/cn";
import type { StrategyId } from "../types";

export const ARENA_BANNER = "CONCEPT PREVIEW — ILLUSTRATIVE DATA — NOT A LIVE QLOO ANALYSIS";

export type ArenaSource = {
  filmTitle: string;
  dataStatus: "measured" | "fixture" | "unavailable" | "none";
  runId?: string;
  completed: boolean;
};

const sampleFilm = "Salt Light";

const stagePhoto: Record<StrategyId, Photo> = {
  anchor: photos.cinemaEmpty,
  bridge: photos.editingTable,
  frontier: photos.projectorLens,
};

const stageSecond: Record<StrategyId, Photo> = {
  anchor: photos.reelTape,
  bridge: photos.nightAlley,
  frontier: photos.filmstrips,
};

export function PositioningArena({ source }: { source: ArenaSource }) {
  const [selected, setSelected] = useState<StrategyId>("anchor");
  const [priorities, setPriorities] = useState<Priorities>({ evidence: 78, distinct: 52, range: 26 });
  const [applied, setApplied] = useState<StrategyId | null>(null);
  const [challenge, setChallenge] = useState(0);
  const [freezeOpen, setFreezeOpen] = useState(false);

  const strategy = strategies.find((s) => s.id === selected)!;
  const index = useMemo(() => previewIndex(priorities), [priorities]);
  const suggestion = useMemo(() => suggestStrategy(priorities), [priorities]);
  const dirty = applied !== null && applied !== suggestion.id;

  return (
    <div className="border border-line bg-ink-2">
      <header className="border-b border-line px-5 py-5 md:px-8">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="type-kicker">Positioning Arena</p>
            <h3 className="font-display mt-2 text-3xl md:text-4xl">
              Three defensible ways to stand in culture.
            </h3>
          </div>
          <span className="chip chip-fixture">{ARENA_BANNER}</span>
        </div>

        <div className="mt-6 grid gap-px bg-line md:grid-cols-3">
          <SourceCell
            label="Source investigation"
            value={source.completed ? source.filmTitle || "Untitled" : "No completed investigation"}
            detail={
              source.completed
                ? `Run ${source.runId ?? "—"} · ${source.dataStatus}`
                : "Run an analysis to attach this arena to a real result later."
            }
          />
          <SourceCell
            label="Preview context"
            value={`Isolated sample · ${sampleFilm}`}
            detail="Strategy content below comes from the concept dataset only."
          />
          <SourceCell
            label="Data status"
            value="Concept preview"
            detail="No Qloo call, no strategy engine, no write."
            chip={<DataChip status="fixture" />}
          />
        </div>

        {source.completed && (
          <p className="mt-4 text-xs leading-relaxed text-amber">
            Your investigation is loaded as source context, but every strategy, evidence row and
            score on this stage is still illustrative. When the strategy engine ships, this stage
            will read the run above instead of the sample dataset.
          </p>
        )}
        {!source.completed && (
          <p className="mt-4 text-xs leading-relaxed text-mute">
            Nothing here was generated from your film brief. This preview does not claim any
            evidence about the film you are entering.
          </p>
        )}
      </header>

      <div className="grid lg:grid-cols-12">
        <div className="border-b border-line lg:col-span-3 lg:border-b-0 lg:border-r">
          <ul>
            {strategies.map((s, i) => (
              <li key={s.id}>
                <button
                  type="button"
                  onClick={() => setSelected(s.id)}
                  aria-pressed={selected === s.id}
                  className={cn(
                    "w-full border-b border-line px-5 py-5 text-left transition-colors",
                    selected === s.id ? "bg-amber/10" : "hover:bg-ink-3"
                  )}
                >
                  <span className="flex items-baseline justify-between gap-2">
                    <span className="type-meta">
                      0{i + 1} · {s.kicker.split("·")[1]?.trim() ?? ""}
                    </span>
                    {applied === s.id && <span className="caption text-sage">applied</span>}
                    {s.id === suggestion.id && applied !== suggestion.id && (
                      <span className="caption text-warn">suggested</span>
                    )}
                  </span>
                  <span
                    className={cn(
                      "font-display mt-1 block text-3xl",
                      selected === s.id ? "text-amber" : "text-paper"
                    )}
                  >
                    {s.name}
                  </span>
                  <span className="mt-1 block text-sm leading-relaxed text-mute">{s.visual}</span>
                </button>
              </li>
            ))}
          </ul>

          <div className="px-5 py-5">
            <p className="type-kicker">What-if lab</p>
            <p className="mt-2 text-xs leading-relaxed text-mute">
              Drag the preferences to compute an illustrative index. Nothing moves until you apply
              it.
            </p>
            <div className="mt-5 space-y-5">
              {(
                [
                  ["evidence", "Evidence strictness"],
                  ["distinct", "Distinctiveness"],
                  ["range", "Exploratory range"],
                ] as const
              ).map(([key, label]) => (
                <label key={key} className="block">
                  <span className="flex justify-between font-mono text-[0.6rem] tracking-[0.14em] uppercase text-amber">
                    {label}
                    <span className="text-paper-2">{priorities[key]}</span>
                  </span>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={priorities[key]}
                    onChange={(e) =>
                      setPriorities((p) => ({ ...p, [key]: Number(e.target.value) }))
                    }
                    className="mt-2 w-full accent-amber"
                  />
                </label>
              ))}
            </div>

            <div className="mt-5 border border-line bg-ink p-3">
              <p className="type-meta">Illustrative index</p>
              <ul className="mt-2 space-y-1">
                {strategies.map((s) => (
                  <li key={s.id} className="flex items-baseline justify-between text-xs">
                    <span className={cn(s.id === suggestion.id ? "text-amber" : "text-mute")}>
                      {s.name}
                    </span>
                    <span className="font-mono tabular-nums text-paper-2">{index[s.id]}</span>
                  </li>
                ))}
              </ul>
            </div>

            <p className="mt-4 text-xs leading-relaxed text-paper-2">
              Suggested: <span className="text-amber">{suggestion.id}</span>. {suggestion.reason}
            </p>
            <p className="mt-2 font-mono text-[0.58rem] leading-relaxed text-dim">
              {suggestion.weights}
            </p>

            <div className="mt-4 flex flex-wrap gap-2">
              <button
                type="button"
                className="btn-amber"
                disabled={suggestion.id === selected}
                onClick={() => {
                  setSelected(suggestion.id);
                  setApplied(suggestion.id);
                }}
              >
                Apply to preview
              </button>
              {applied && applied !== suggestion.id && (
                <button type="button" className="btn-ghost" onClick={() => setApplied(null)}>
                  Clear applied
                </button>
              )}
            </div>
            <p className="mt-3 caption">
              Weights shown above. Demonstration rule only — not a production ranking model.
            </p>
            {dirty && (
              <p className="mt-2 caption text-warn">
                The weights changed after your last apply — selected and suggested remain distinct.
              </p>
            )}
          </div>
        </div>

        <div className="lg:col-span-6">
          <div className="relative min-h-[300px] md:min-h-[380px]">
            <PhotoFrame
              photo={stagePhoto[selected]}
              className="absolute inset-0"
              credit={false}
              imgClassName={cn(selected === "frontier" && "object-[20%_center]")}
            />
            <div
              className={cn(
                "absolute inset-0",
                selected === "anchor" && "bg-gradient-to-t from-ink via-ink/55 to-transparent",
                selected === "bridge" && "bg-gradient-to-r from-ink/85 via-ink/40 to-ink/85",
                selected === "frontier" && "bg-gradient-to-r from-ink via-ink/75 to-transparent"
              )}
            />
            <div
              className={cn(
                "relative z-10 flex min-h-[300px] flex-col justify-end p-6 md:min-h-[380px] md:p-8",
                selected === "bridge" && "items-center text-center",
                selected === "frontier" && "max-w-md"
              )}
            >
              <p className="type-kicker">{strategy.name}</p>
              <h4
                className={cn(
                  "font-display mt-3 leading-[0.95] text-paper",
                  selected === "frontier" ? "text-4xl md:text-5xl" : "text-3xl md:text-5xl",
                  selected === "anchor" && "text-center"
                )}
              >
                {strategy.headline}
              </h4>
              <p className="mt-4 max-w-md text-sm leading-relaxed text-paper-2">
                {strategy.lede}
              </p>
            </div>
          </div>

          <div className="border-t border-line p-5 md:p-6">
            <p className="type-kicker">Positioning brief</p>
            <p className="mt-3 text-sm leading-relaxed text-paper-2">{strategy.body}</p>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <div className="border border-line p-3">
                <p className="type-meta">Worlds held</p>
                <p className="mt-2 text-sm text-paper">{strategy.worlds.a}</p>
                <p className="mt-1 text-sm text-paper">{strategy.worlds.b}</p>
              </div>
              <div className="border border-line p-3">
                <p className="type-meta">Visual character</p>
                <p className="mt-2 text-sm text-paper-2">{strategy.visual}</p>
              </div>
            </div>
            <div className="mt-5 flex gap-2 overflow-hidden border border-line">
              {[stagePhoto[selected], stageSecond[selected], photos.soho].map((p, i) => (
                <div key={i} className="h-16 flex-1">
                  <PhotoFrame photo={p} className="h-full" credit={false} />
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="border-t border-line lg:col-span-3 lg:border-l lg:border-t-0">
          <div className="border-b border-line p-5">
            <p className="type-kicker">Evidence challenge</p>
            <ul className="mt-4 space-y-3">
              {strategy.evidence.map((row, i) => (
                <li key={row.label} className="border border-line p-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setChallenge(i)}
                      className={cn(
                        "text-left font-mono text-[0.6rem] uppercase tracking-[0.14em]",
                        challenge === i ? "text-amber" : "text-paper-2"
                      )}
                    >
                      {row.label}
                    </button>
                    <span className="chip chip-unk">{row.kind.split(" · ")[0]}</span>
                  </div>
                  {challenge === i && (
                    <p className="drawer-enter mt-2 text-xs leading-relaxed text-mute">
                      {row.note}
                    </p>
                  )}
                </li>
              ))}
            </ul>
            <div className="mt-4 space-y-2">
              <p className="caption">Limitations</p>
              <ul className="space-y-2">
                {strategy.risks.map((r) => (
                  <li key={r} className="text-xs leading-relaxed text-paper-2">
                    — {r}
                  </li>
                ))}
              </ul>
            </div>
            <div className="mt-4 border-t border-line pt-4">
              <div className="flex flex-wrap gap-2">
                <ClaimChip kind="HYPOTHESIS" />
                <span className="chip chip-warn">Falsifiable</span>
              </div>
              <p className="mt-3 text-xs leading-relaxed text-paper-2">
                {sampleFilm} positions as <em>{strategy.name.toLowerCase()}</em>; if independent
                reviewers cannot name the frame without prompting within the observation window, the
                strategy is withdrawn.
              </p>
              <p className="mt-2 caption">Illustrative hypothesis — not your saved plan.</p>
            </div>
          </div>

          <div className="p-5">
            <p className="type-kicker">Freeze decision</p>
            <p className="mt-3 text-xs leading-relaxed text-mute">
              Freezing saves the selected strategy as an immutable decision snapshot and links it to
              a planned experiment. The strategy engine is not connected, so freezing is disabled
              here — writing now would fabricate a decision in your real archive.
            </p>
            <button
              type="button"
              className="btn-ghost mt-4 w-full justify-center"
              disabled
              aria-disabled="true"
              title="Design-only until the strategy engine ships"
            >
              <Snowflake size={14} />
              Freeze decision
            </button>
            <button
              type="button"
              className="btn-amber mt-3 w-full justify-center"
              onClick={() => setFreezeOpen((v) => !v)}
              aria-expanded={freezeOpen}
            >
              <Lock size={13} />
              {freezeOpen ? "Hide snapshot preview" : "Preview snapshot record"}
            </button>
            {freezeOpen && (
              <div className="drawer-enter mt-4 border border-line bg-ink p-3">
                <p className="type-meta">Design-only record</p>
                <dl className="mt-3 space-y-2 text-xs">
                  <Line k="strategy" v={strategy.name.toUpperCase()} />
                  <Line k="source_run" v={source.runId ?? "— none attached —"} />
                  <Line k="status" v="NOT SAVED · concept preview" />
                  <Line k="priorities" v={`E${priorities.evidence} D${priorities.distinct} R${priorities.range}`} />
                </dl>
                <p className="mt-3 flex items-center gap-1 text-[0.65rem] text-dim">
                  Nothing was written. <ArrowRight size={11} />
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {applied !== null && (
        <p className="border-t border-line px-5 py-3 caption">
          Suggestion applied to preview on {applied}. Selected and suggested stay visually distinct
          until you apply again.
        </p>
      )}
    </div>
  );
}

function SourceCell({
  label,
  value,
  detail,
  chip,
}: {
  label: string;
  value: string;
  detail: string;
  chip?: ReactNode;
}) {
  return (
    <div className="bg-ink-2 p-4">
      <p className="type-meta">{label}</p>
      <p className="font-display mt-2 text-xl">{value}</p>
      {chip && <div className="mt-2">{chip}</div>}
      <p className="mt-2 text-xs leading-relaxed text-mute">{detail}</p>
    </div>
  );
}

function Line({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-dim">{k}</dt>
      <dd className="text-right text-paper-2">{v}</dd>
    </div>
  );
}
