import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import type { Route } from "../types";
import { Wordmark } from "./Wordmark";
import { cn } from "../utils/cn";

const LINKS: { id: Route; label: string }[] = [
  { id: "home", label: "Index" },
  { id: "creator", label: "Creator Studio" },
  { id: "cinema", label: "Cinema Mode" },
  { id: "sponsor", label: "FilmSponsor" },
];

export function Nav({
  route,
  onNavigate,
  overlay = false,
}: {
  route: Route;
  onNavigate: (r: Route) => void;
  overlay?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [route]);

  return (
    <header
      className={cn(
        "sticky top-0 z-50 transition-colors duration-300",
        overlay && !scrolled && !open
          ? "bg-transparent"
          : "bg-ink/92 backdrop-blur-md border-b border-line"
      )}
    >
      <div className="mx-auto flex max-w-[1440px] items-center justify-between gap-4 px-4 py-3 md:px-8">
        <Wordmark onNavigate={onNavigate} />

        <nav className="hidden items-center gap-8 lg:flex" aria-label="Primary">
          {LINKS.map((link) => (
            <button
              key={link.id}
              type="button"
              className={cn("nav-link", route === link.id && "is-active")}
              onClick={() => onNavigate(link.id)}
            >
              {link.label}
            </button>
          ))}
        </nav>

        <div className="hidden items-center gap-4 lg:flex">
          <span className="type-meta text-[0.58rem]">Vol. 01 · The Culture Room</span>
        </div>

        <button
          type="button"
          className="inline-flex h-11 w-11 items-center justify-center border border-line-strong text-paper lg:hidden"
          aria-expanded={open}
          aria-controls="mobile-nav"
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X size={18} /> : <Menu size={18} />}
        </button>
      </div>

      {open && (
        <div id="mobile-nav" className="border-t border-line bg-ink px-4 py-4 lg:hidden">
          <nav className="flex flex-col" aria-label="Mobile">
            {LINKS.map((link) => (
              <button
                key={link.id}
                type="button"
                className={cn(
                  "flex h-12 items-center justify-between border-b border-line text-left font-mono text-xs tracking-[0.16em] uppercase",
                  route === link.id ? "text-amber" : "text-paper"
                )}
                onClick={() => onNavigate(link.id)}
              >
                {link.label}
                <span className="text-dim">0{LINKS.indexOf(link) + 1}</span>
              </button>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
