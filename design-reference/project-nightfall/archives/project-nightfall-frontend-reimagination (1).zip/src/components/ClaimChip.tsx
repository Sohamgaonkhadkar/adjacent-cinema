import type { ClaimKind, DataStatus, EvaluationVerdict, ObservationKind, RunStatus } from "../types";
import { cn } from "../utils/cn";

export function ClaimChip({ kind }: { kind: ClaimKind }) {
  const map: Record<ClaimKind, string> = {
    FACT: "chip chip-fact",
    INTERPRETATION: "chip chip-interp",
    HYPOTHESIS: "chip chip-hyp",
    UNKNOWN: "chip chip-unk",
  };
  return <span className={map[kind]}>{kind}</span>;
}

export function DataChip({ status }: { status: DataStatus }) {
  if (status === "fixture") return <span className="chip chip-fixture">Fixture</span>;
  if (status === "live") return <span className="chip chip-live">Live Qloo</span>;
  if (status === "unavailable") return <span className="chip chip-warn">Unavailable</span>;
  if (status === "insufficient") return <span className="chip chip-warn">Insufficient evidence</span>;
  return <span className="chip chip-fail">Failed</span>;
}

export function RunChip({ status }: { status: RunStatus }) {
  const label: Record<RunStatus, string> = {
    idle: "Idle",
    running: "Running",
    completed: "Completed",
    insufficient: "Insufficient evidence",
    failed: "Failed",
    unavailable: "Unavailable",
    cancelled: "Cancelled",
  };
  return (
    <span
      className={cn(
        "chip",
        status === "completed" && "chip-live",
        status === "running" && "chip-fact",
        (status === "failed" || status === "cancelled") && "chip-fail",
        (status === "insufficient" || status === "unavailable") && "chip-warn",
        status === "idle" && "chip-unk"
      )}
    >
      {label[status]}
    </span>
  );
}

export function VerdictChip({ verdict }: { verdict: EvaluationVerdict }) {
  const cls =
    verdict === "SUPPORTED" ? "chip-live" : verdict === "CONTRADICTED" ? "chip-fail" : "chip-warn";
  return <span className={cn("chip", cls)}>{verdict}</span>;
}

export function ObservationChip({ kind }: { kind: ObservationKind }) {
  return <span className="chip chip-interp">{kind}</span>;
}
