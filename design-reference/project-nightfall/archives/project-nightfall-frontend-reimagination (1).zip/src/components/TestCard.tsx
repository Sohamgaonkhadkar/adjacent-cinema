import { Download, Lock, Pencil } from "lucide-react";
import type { TestCardData } from "../types";
import { downloadText, testCardToText } from "../lib/exportTestCard";
import { DataChip } from "./ClaimChip";
import { Field, TextArea } from "./Field";

type Props = {
  card: TestCardData;
  editing: boolean;
  onChange?: (card: TestCardData) => void;
  onToggleEdit?: () => void;
  bet?: string;
  runId?: string;
};

const FIELDS: { key: keyof TestCardData; label: string; hint: string }[] = [
  {
    key: "hypothesis",
    label: "Hypothesis",
    hint: "A test of cultural positioning — not a prediction of views or revenue.",
  },
  {
    key: "comparisonProtocol",
    label: "Comparison protocol",
    hint: "How two frames will be compared. Randomised only if the platform actually supports it.",
  },
  {
    key: "primaryMeasure",
    label: "Primary measure",
    hint: "One observable. Zero is zero. Missing stays missing.",
  },
  {
    key: "decisionRule",
    label: "Decision rule",
    hint: "Set by you before launch. The product does not invent a success threshold.",
  },
  {
    key: "observationWindow",
    label: "Observation window",
    hint: "When the comparison is allowed to close.",
  },
  {
    key: "falsification",
    label: "Falsification",
    hint: "What would contradict the bet — written before results arrive.",
  },
];

export function TestCard({ card, editing, onChange, onToggleEdit, bet, runId }: Props) {
  const exportCard = () => {
    const name = (card.filmTitle || "test-card")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "");
    downloadText(`${name || "test-card"}.txt`, testCardToText(card, { bet, runId }));
  };

  return (
    <article className="paper-card relative overflow-hidden">
      <div className="pointer-events-none absolute inset-y-0 left-0 w-3 bg-[repeating-linear-gradient(to_bottom,transparent_0_10px,#c29a6e_10px_12px,transparent_12px_22px)] opacity-40" />
      <div className="pointer-events-none absolute inset-y-0 right-0 w-3 bg-[repeating-linear-gradient(to_bottom,transparent_0_10px,#c29a6e_10px_12px,transparent_12px_22px)] opacity-40" />

      <header className="flex flex-wrap items-start justify-between gap-4 border-b border-ink/10 px-6 py-5 md:px-10">
        <div>
          <p className="font-mono text-[0.62rem] tracking-[0.2em] uppercase text-amber-2">
            Test Card · planned experiment
          </p>
          <h3 className="font-display mt-2 text-3xl leading-none md:text-4xl">
            {card.filmTitle || "Untitled investigation"}
          </h3>
          <p className="mt-2 max-w-xl text-sm text-ink/60">
            A production notebook, not a result. Saving records a plan — it does not run the
            experiment.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <DataChip status={card.dataStatus} />
          <span className="chip" style={{ color: "#5c574e" }}>
            {editing ? "Editing" : "Read"}
          </span>
        </div>
      </header>

      <div className="space-y-7 px-6 py-7 md:px-10">
        {FIELDS.map((field) => (
          <div key={field.key}>
            {editing && onChange ? (
              <Field label={field.label} hint={field.hint}>
                <TextArea
                  className="border-ink/20 text-ink placeholder:text-ink/30"
                  value={String(card[field.key] ?? "")}
                  onChange={(e) => onChange({ ...card, [field.key]: e.target.value })}
                />
              </Field>
            ) : (
              <>
                <p className="font-mono text-[0.62rem] tracking-[0.16em] uppercase text-amber-2">
                  {field.label}
                </p>
                <p className="mt-2 text-[0.95rem] leading-relaxed text-ink/85">
                  {String(card[field.key] || "— not yet written —")}
                </p>
              </>
            )}
          </div>
        ))}
      </div>

      <footer className="flex flex-wrap items-center justify-between gap-3 border-t border-ink/10 px-6 py-4 md:px-10">
        <p className="font-mono text-[0.58rem] tracking-[0.12em] uppercase text-ink/45">
          Affinity ≠ audience · plan ≠ outcome
        </p>
        <div className="flex flex-wrap gap-2">
          {onToggleEdit && (
            <button type="button" className="btn-ghost !text-ink !border-ink/20" onClick={onToggleEdit}>
              {editing ? <Lock size={14} /> : <Pencil size={14} />}
              {editing ? "Lock card" : "Edit card"}
            </button>
          )}
          <button type="button" className="btn-primary" onClick={exportCard}>
            <Download size={14} />
            Export .txt
          </button>
        </div>
      </footer>
    </article>
  );
}
